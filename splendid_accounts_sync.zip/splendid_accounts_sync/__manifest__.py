{
    "name": "Splendid Accounts Sync",
    "summary": "Import Splendid Accounts master data into Odoo",
    "version": "18.0.3.0.0",
    "category": "Accounting/Accounting",
    "author": "Ideabox Technology",
    "license": "LGPL-3",
    "depends": [
        "base",
        "mail",
        "contacts",
        "account",
        "product",
        "stock",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/splendid_views.xml",
        "views/splendid_end_to_end_views.xml",
        "data/ir_cron.xml",
    ],
    "installable": True,
    "application": True,
}
