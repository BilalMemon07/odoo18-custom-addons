# -*- coding: utf-8 -*-
import hashlib
import json
import logging
import re
from datetime import datetime
from urllib.parse import urljoin

import requests

from odoo import _, api, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)


class SplendidAccountConnection(models.Model):
    _name = "splendid.account.connection"
    _description = "Splendid Accounts API Connection"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "name"

    name = fields.Char(required=True, default="Splendid Accounts")
    active = fields.Boolean(default=True)
    base_url = fields.Char(required=True, default="https://app.splendidaccounts.com")
    tenant = fields.Char(required=True)
    branch = fields.Char(required=True)
    api_key = fields.Char(required=True, string="API Key")
    api_secret = fields.Char(required=True, string="API Secret")
    app_id = fields.Char(required=True, string="App ID")
    company_id = fields.Many2one("res.company", required=True, default=lambda self: self.env.company)
    page_size = fields.Integer(default=100)
    timeout = fields.Integer(default=60)
    verify_ssl = fields.Boolean(default=True)

    last_master_sync = fields.Datetime(copy=False)
    last_chart_accounts_sync = fields.Datetime(copy=False, string="Last Chart of Accounts Sync")
    last_customers_sync = fields.Datetime(copy=False, string="Last Customers Sync")
    last_vendors_sync = fields.Datetime(copy=False, string="Last Vendors Sync")
    last_products_sync = fields.Datetime(copy=False, string="Last Products Sync")
    last_get_products_sync = fields.Datetime(copy=False, string="Last Get Products Sync")
    last_warehouses_sync = fields.Datetime(copy=False, string="Last Warehouses Sync")
    last_bank_accounts_sync = fields.Datetime(copy=False, string="Last Bank Accounts Sync")
    last_taxes_sync = fields.Datetime(copy=False, string="Last Taxes Sync")

    # Kept for backward compatibility with previous module versions/views/crons.
    last_transaction_sync = fields.Datetime(copy=False)
    last_inventory_sync = fields.Datetime(copy=False)
    last_manufacturing_sync = fields.Datetime(copy=False)
    last_full_sync = fields.Datetime(copy=False)

    chart_accounts_fetched_count = fields.Integer(copy=False, readonly=True)
    chart_accounts_imported_count = fields.Integer(copy=False, readonly=True)
    chart_accounts_failed_count = fields.Integer(copy=False, readonly=True)
    customers_fetched_count = fields.Integer(copy=False, readonly=True)
    customers_imported_count = fields.Integer(copy=False, readonly=True)
    customers_failed_count = fields.Integer(copy=False, readonly=True)
    vendors_fetched_count = fields.Integer(copy=False, readonly=True)
    vendors_imported_count = fields.Integer(copy=False, readonly=True)
    vendors_failed_count = fields.Integer(copy=False, readonly=True)
    products_fetched_count = fields.Integer(copy=False, readonly=True)
    products_imported_count = fields.Integer(copy=False, readonly=True)
    products_failed_count = fields.Integer(copy=False, readonly=True)
    warehouses_fetched_count = fields.Integer(copy=False, readonly=True)
    warehouses_imported_count = fields.Integer(copy=False, readonly=True)
    warehouses_failed_count = fields.Integer(copy=False, readonly=True)
    bank_accounts_fetched_count = fields.Integer(copy=False, readonly=True)
    bank_accounts_imported_count = fields.Integer(copy=False, readonly=True)
    bank_accounts_failed_count = fields.Integer(copy=False, readonly=True)
    taxes_fetched_count = fields.Integer(copy=False, readonly=True)
    taxes_imported_count = fields.Integer(copy=False, readonly=True)
    taxes_failed_count = fields.Integer(copy=False, readonly=True)

    default_receivable_account_id = fields.Many2one("account.account", domain="[('account_type','=','asset_receivable'), ('deprecated','=',False)]")
    default_payable_account_id = fields.Many2one("account.account", domain="[('account_type','=','liability_payable'), ('deprecated','=',False)]")
    default_income_account_id = fields.Many2one("account.account", domain="[('account_type','in',('income','income_other')), ('deprecated','=',False)]")
    default_expense_account_id = fields.Many2one("account.account", domain="[('account_type','in',('expense','expense_direct_cost')), ('deprecated','=',False)]")
    default_stock_account_id = fields.Many2one("account.account", domain="[('account_type','in',('asset_current','asset_fixed')), ('deprecated','=',False)]")

    log_ids = fields.One2many("splendid.sync.log", "connection_id")
    mapping_ids = fields.One2many("splendid.sync.map", "connection_id")

    MASTER_ENDPOINTS = {
        "chart_accounts": "/Accounts",
        "customers": "/Customers",
        "vendors": "/Vendors",
        "products": "/Products",
        "warehouses": "/api/{tenant}/{branch}/Entities/Warehouses",
        "bank_accounts": "/api/{tenant}/{branch}/BankAccounts",
        "taxes": "/api/{tenant}/Taxes",
    }

    def _with_target_company(self):
        self.ensure_one()
        return self.with_company(self.company_id).with_context(
            allowed_company_ids=[self.company_id.id],
            force_company=self.company_id.id,
        )

    @api.onchange("company_id")
    def _onchange_company_id(self):
        for rec in self:
            rec.default_receivable_account_id = False
            rec.default_payable_account_id = False
            rec.default_income_account_id = False
            rec.default_expense_account_id = False
            rec.default_stock_account_id = False

    def _headers(self):
        self.ensure_one()
        return {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "X-Api-Key": self.api_key or "",
            "X-Api-Secret": self.api_secret or "",
            "X-App-Id": self.app_id or "",
        }

    def _api_path(self, endpoint):
        endpoint = endpoint.strip()
        if endpoint.startswith("/api/"):
            return endpoint.format(tenant=self.tenant, branch=self.branch)
        return "/api/%s/%s%s" % (self.tenant, self.branch, endpoint if endpoint.startswith("/") else "/" + endpoint)

    def _api_url(self, endpoint):
        self.ensure_one()
        return urljoin(self.base_url.rstrip("/") + "/", self._api_path(endpoint).lstrip("/"))

    def _api_request(self, method, endpoint, params=None, payload=None):
        self.ensure_one()
        url = self._api_url(endpoint)
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                params=params or {},
                json=payload,
                timeout=self.timeout or 60,
                verify=self.verify_ssl,
            )
            response.raise_for_status()
        except requests.exceptions.RequestException as exc:
            raise UserError(_("Splendid API request failed: %s") % exc) from exc
        if not response.content:
            return {}
        try:
            return response.json()
        except ValueError:
            return {"raw": response.text}

    def _extract_list(self, data):
        if not data:
            return []
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            for key in ("data", "items", "records", "results", "result", "value", "list", "rows"):
                value = data.get(key)
                if isinstance(value, list):
                    return value
                if isinstance(value, dict):
                    nested = self._extract_list(value)
                    if nested:
                        return nested
            for value in data.values():
                if isinstance(value, list):
                    return value
            if any(str(k).lower() in data for k in ("id", "code", "number", "name")):
                return [data]
        return []

    def _fetch_collection(self, endpoint, params=None, use_paging=True):
        self.ensure_one()
        all_rows = []
        page = 1
        size = self.page_size or 100
        while True:
            request_params = dict(params or {})
            if use_paging:
                request_params.setdefault("page", page)
                request_params.setdefault("size", size)
            data = self._api_request("GET", endpoint, params=request_params)
            rows = self._extract_list(data)
            all_rows.extend(rows)
            if not use_paging or len(rows) < size or not rows:
                break
            page += 1
            if page > 10000:
                raise UserError(_("Paging stopped after 10,000 pages for endpoint %s") % endpoint)
        return all_rows

    def _find_value(self, payload, *keys, default=False):
        if not isinstance(payload, dict):
            return default
        lower = {str(k).lower(): v for k, v in payload.items()}
        for key in keys:
            if key in payload:
                return payload[key]
            value = lower.get(str(key).lower())
            if value is not None:
                return value
        return default

    def _nested(self, payload, key):
        value = self._find_value(payload, key)
        return value if isinstance(value, dict) else {}

    def _external_id(self, payload):
        value = self._find_value(payload, "id", "Id", "externalId", "sourceId")
        if value in (False, None, ""):
            value = self._find_value(payload, "number", "code", "sku", "name")
        return str(value or "")

    def _payload_hash(self, payload):
        raw = json.dumps(payload or {}, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _company_partner(self):
        return self.company_id.partner_id

    def _account_company_domain(self):
        account_fields = self.env["account.account"]._fields
        if "company_id" in account_fields:
            return [("company_id", "=", self.company_id.id)]
        if "company_ids" in account_fields:
            return [("company_ids", "in", self.company_id.id)]
        return []

    def _clean_account_code(self, code):
        code = str(code or "").strip()
        code = re.sub(r"[\s\-_/]+", ".", code)
        code = re.sub(r"[^A-Za-z0-9.]", "", code)
        code = re.sub(r"\.+", ".", code).strip(".")
        return code[:64]

    def _clean_product_code(self, value, fallback=False):
        code = str(value or fallback or "").strip()
        if not code:
            return False
        return re.sub(r"\s+", " ", code)[:100]

    def _safe_float(self, value, default=0.0):
        if value in (False, None, ""):
            return default
        if isinstance(value, (int, float)):
            return float(value)
        text = re.sub(r"[^0-9.\-]", "", str(value).strip())
        if text in ("", ".", "-", "-."):
            return default
        try:
            return float(text)
        except ValueError:
            return default

    def _safe_bool(self, value, default=False):
        if value in (False, None, ""):
            return default
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return bool(value)
        text = str(value).strip().lower()
        if text in ("true", "1", "yes", "y", "active"):
            return True
        if text in ("false", "0", "no", "n", "inactive"):
            return False
        return default

    def _map_search(self, external_model, external_id, odoo_model):
        return self.env["splendid.sync.map"].sudo().search([
            ("connection_id", "=", self.id),
            ("external_model", "=", external_model),
            ("external_id", "=", str(external_id)),
            ("odoo_model", "=", odoo_model),
        ], limit=1)

    def _mapped_record(self, external_model, external_id, odoo_model):
        mapping = self._map_search(external_model, external_id, odoo_model)
        if mapping and mapping.res_id:
            return self.env[odoo_model].with_company(self.company_id).sudo().browse(mapping.res_id).exists()
        return self.env[odoo_model].with_company(self.company_id)

    def _set_mapping(self, external_model, external_id, odoo_record, payload=None, external_name=None):
        if not external_id or not odoo_record:
            return False
        vals = {
            "connection_id": self.id,
            "external_model": external_model,
            "external_id": str(external_id),
            "external_name": external_name or self._find_value(payload or {}, "name", "displayName", "number", "code"),
            "odoo_model": odoo_record._name,
            "res_id": odoo_record.id,
            "last_payload_hash": self._payload_hash(payload),
            "last_sync_date": fields.Datetime.now(),
        }
        mapping = self._map_search(external_model, external_id, odoo_record._name)
        if mapping:
            mapping.write(vals)
        else:
            mapping = self.env["splendid.sync.map"].with_company(self.company_id).sudo().create(vals)
        return mapping

    def _log(self, sync_type, state, message=None, payload=None, external_id=None, record=None):
        self.env["splendid.sync.log"].with_company(self.company_id).sudo().create({
            "connection_id": self.id,
            "sync_type": sync_type,
            "state": state,
            "message": message,
            "payload": payload,
            "external_id": str(external_id or ""),
            "odoo_model": record._name if record else False,
            "res_id": record.id if record else False,
        })

    def _set_count(self, key, fetched, imported, failed):
        field_vals = {}
        for suffix, value in (("fetched_count", fetched), ("imported_count", imported), ("failed_count", failed)):
            field_name = "%s_%s" % (key, suffix)
            if field_name in self._fields:
                field_vals[field_name] = value
        if field_vals:
            self.write(field_vals)

    def _search_account_by_external_or_code(self, external_id=False, code=False):
        Account = self.env["account.account"].with_company(self.company_id).sudo()
        domain_company = self._account_company_domain()
        if external_id not in (False, None, ""):
            account = Account.search([("splendid_account_id", "=", str(external_id))] + domain_company, limit=1)
            if account:
                return account
            mapped = self._mapped_record("account", external_id, "account.account")
            if mapped:
                return mapped
        code = self._clean_account_code(code)
        if code:
            account = Account.search([("code", "=", code)] + domain_company, limit=1)
            if account:
                return account
        return Account

    def _resolve_account(self, external_id=False, code=False):
        account = self._search_account_by_external_or_code(external_id, code)
        if account:
            return account
        if external_id:
            try:
                payload = self._api_request("GET", "/Accounts/%s" % external_id)
                rows = self._extract_list(payload)
                if rows:
                    return self._import_chart_accounts(rows[0])
                if isinstance(payload, dict) and payload:
                    return self._import_chart_accounts(payload)
            except Exception as exc:  # pylint: disable=broad-except
                _logger.warning("Could not fetch Splendid account %s: %s", external_id, exc)
        return account

    def _default_account(self, kind):
        account = {
            "income": self.default_income_account_id,
            "expense": self.default_expense_account_id,
            "receivable": self.default_receivable_account_id,
            "payable": self.default_payable_account_id,
            "stock": self.default_stock_account_id,
        }.get(kind)
        if account:
            return account
        type_map = {
            "income": ("income", "income_other"),
            "expense": ("expense", "expense_direct_cost"),
            "receivable": ("asset_receivable",),
            "payable": ("liability_payable",),
            "stock": ("asset_current", "asset_fixed"),
        }
        domain = [("deprecated", "=", False), ("account_type", "in", type_map.get(kind, ("asset_current",)))] + self._account_company_domain()
        account = self.env["account.account"].with_company(self.company_id).sudo().search(domain, limit=1)
        return account

    def action_test_connection(self):
        for rec in self:
            rec = rec._with_target_company()
            data = rec._api_request("GET", "/Accounts", params={"page": 1, "size": 1})
            rec.message_post(body=_("Splendid connection successful. Response preview: %s") % json.dumps(data, default=str)[:500])
        return True

    def action_sync_masters(self):
        for rec in self:
            rec = rec._with_target_company()
            rec._sync_masters()
        return True

    def action_get_products(self):
        for rec in self:
            rec = rec._with_target_company()
            rec._sync_master_model("products")
            rec.last_get_products_sync = fields.Datetime.now()
        return True

    # Backward-compatible methods. These no longer sync transactions or inventory.
    def action_sync_transactions(self):
        raise UserError(_("Transaction sync has been removed from this master-data-only version. Use Sync Master Data."))

    def action_sync_inventory(self):
        raise UserError(_("Inventory sync has been removed from this master-data-only version. Use Sync Master Data."))

    def action_sync_manufacturing(self):
        raise UserError(_("Manufacturing sync has been removed from this master-data-only version. Use Sync Master Data."))

    def action_sync_all(self):
        return self.action_sync_masters()

    @api.model
    def cron_sync_all_active(self):
        for connection in self.search([("active", "=", True)]):
            try:
                connection._with_target_company()._sync_masters()
            except Exception as exc:  # pylint: disable=broad-except
                _logger.exception("Splendid cron failed for %s", connection.display_name)
                connection._log("cron", "error", str(exc))

    def _sync_masters(self):
        self.ensure_one()
        for key in ("chart_accounts", "customers", "vendors", "products", "warehouses", "bank_accounts", "taxes"):
            self._sync_master_model(key)
        self.last_master_sync = fields.Datetime.now()
        self.env.cr.commit()

    def _sync_master_model(self, key):
        self.ensure_one()
        endpoint = self.MASTER_ENDPOINTS.get(key)
        if not endpoint:
            raise UserError(_("No Splendid endpoint configured for %s") % key)
        importer = getattr(self, "_import_%s" % key, None)
        if not importer:
            raise UserError(_("No importer defined for %s") % key)
        params = self._params_for_master(key)
        rows = self._fetch_collection(endpoint, params=params, use_paging=True)
        imported = 0
        failed = 0
        for payload in rows:
            external_id = self._external_id(payload)
            try:
                record = importer(payload)
                imported += 1
                self._log(key, "success", "Imported/Updated", payload, external_id, record)
            except Exception as exc:  # pylint: disable=broad-except
                failed += 1
                _logger.exception("Failed to import Splendid %s/%s", key, external_id)
                self._log(key, "error", str(exc), payload, external_id)
        self._set_count(key, len(rows), imported, failed)
        last_field = "last_%s_sync" % key
        if last_field in self._fields:
            self.write({last_field: fields.Datetime.now()})
        if key == "products":
            self.last_get_products_sync = fields.Datetime.now()
        self.env.cr.commit()
        return True

    def _params_for_master(self, key):
        base = {"orderBy": "Id", "ascending": "true"}
        if key in ("products",):
            base["showOpening"] = "false"
        return base

    def _import_chart_accounts(self, payload):
        external_id = self._external_id(payload)
        raw_code = self._find_value(payload, "code", "number", "accountCode", "accountNumber", "accountNo")
        code = self._clean_account_code(raw_code or external_id)
        if not code:
            raise UserError(_("Missing account code for Splendid account %s") % external_id)
        name = self._find_value(payload, "name", "displayName", "description") or code
        vals = {
            "code": code,
            "name": name,
            "account_type": self._map_account_type(payload),
            "splendid_account_id": external_id,
            "splendid_is_imported": True,
        }
        account_fields = self.env["account.account"]._fields
        if "company_id" in account_fields:
            vals["company_id"] = self.company_id.id
        elif "company_ids" in account_fields:
            vals["company_ids"] = [(4, self.company_id.id)]
        account = self._mapped_record("account", external_id, "account.account")
        if not account:
            account = self._search_account_by_external_or_code(external_id, code)
        if account:
            account.write(vals)
        else:
            account = self.env["account.account"].with_company(self.company_id).sudo().create(vals)
        self._set_mapping("account", external_id, account, payload, name)
        return account

    def _map_account_type(self, payload):
        text = " ".join(str(x or "") for x in (
            self._find_value(payload, "accountType", "accountTypeId"),
            self._find_value(payload, "accountClass"),
            self._find_value(payload, "accountGroup"),
            self._find_value(payload, "name"),
            self._find_value(payload, "code"),
        )).lower()
        if "receivable" in text or "customer" in text:
            return "asset_receivable"
        if "payable" in text or "vendor" in text or "supplier" in text:
            return "liability_payable"
        if "bank" in text or "cash" in text:
            return "asset_cash"
        if "fixed" in text and "asset" in text:
            return "asset_fixed"
        if "asset" in text:
            return "asset_current"
        if "liabil" in text:
            return "liability_current"
        if "equity" in text or "capital" in text:
            return "equity"
        if "cost" in text:
            return "expense_direct_cost"
        if "expense" in text:
            return "expense"
        if "income" in text or "revenue" in text or "sale" in text:
            return "income"
        return "expense"

    def _import_customers(self, payload):
        return self._import_partner(payload, "customer")

    def _import_vendors(self, payload):
        return self._import_partner(payload, "vendor")

    def _import_partner(self, payload, partner_type):
        external_id = self._external_id(payload)
        model_key = "customer" if partner_type == "customer" else "vendor"
        partner = self._mapped_record(model_key, external_id, "res.partner")
        name = self._find_value(payload, "name", "displayName", "printName", "contactPerson") or _("Splendid Contact %s") % external_id
        vals = {
            "name": name,
            "street": self._find_value(payload, "address1", "address"),
            "street2": self._find_value(payload, "address2"),
            "city": self._find_value(payload, "city"),
            "zip": self._find_value(payload, "zip", "postalCode"),
            "email": self._find_value(payload, "email", "email1"),
            "phone": self._find_value(payload, "phone", "phone1"),
            "mobile": self._find_value(payload, "phone2", "mobile"),
            "ref": self._find_value(payload, "code", "number") or external_id,
            "splendid_is_imported": True,
            "company_type": "company",
        }
        if "company_id" in self.env["res.partner"]._fields:
            vals["company_id"] = self.company_id.id
        if partner_type == "customer":
            vals.update({"customer_rank": 1, "splendid_customer_id": external_id})
            account = self._resolve_account(self._find_value(payload, "accountId")) or self.default_receivable_account_id
            if account and account.account_type == "asset_receivable":
                vals["property_account_receivable_id"] = account.id
        else:
            vals.update({"supplier_rank": 1, "splendid_vendor_id": external_id})
            account = self._resolve_account(self._find_value(payload, "accountId")) or self.default_payable_account_id
            if account and account.account_type == "liability_payable":
                vals["property_account_payable_id"] = account.id
        vals = {k: v for k, v in vals.items() if v not in (False, None)}
        if not partner:
            domain = []
            if vals.get("email"):
                domain = [("email", "=", vals["email"])]
            elif vals.get("ref"):
                domain = [("ref", "=", vals["ref"])]
            if domain and "company_id" in self.env["res.partner"]._fields:
                domain = ["&"] + domain + ["|", ("company_id", "=", False), ("company_id", "=", self.company_id.id)]
            partner = self.env["res.partner"].with_company(self.company_id).sudo().search(domain, limit=1) if domain else self.env["res.partner"].with_company(self.company_id)
        if partner:
            partner.write(vals)
        else:
            partner = self.env["res.partner"].with_company(self.company_id).sudo().create(vals)
        self._set_mapping(model_key, external_id, partner, payload, name)
        return partner

    def _product_external_id(self, payload):
        value = self._find_value(payload, "id", "Id", "productId", "ProductId", "productID", "externalId", "sourceId")
        if value in (False, None, ""):
            value = self._find_value(payload, "sku", "code", "number", "barcode", "name")
        return str(value or "")

    def _import_products(self, payload):
        external_id = self._product_external_id(payload)
        product = self._mapped_record("product", external_id, "product.template")
        name = self._find_value(payload, "name", "displayName", "shortName", "sku", "code") or _("Splendid Product %s") % external_id
        sku = self._clean_product_code(self._find_value(payload, "sku", "code", "number"), fallback=external_id)
        if not sku:
            sku = self._clean_product_code(name, fallback=external_id)
        vals = {
            "name": str(name)[:1000],
            "default_code": sku,
            "list_price": self._safe_float(self._find_value(payload, "salePrice", "maximumRetailPrice"), 0.0),
            "standard_price": self._safe_float(self._find_value(payload, "purchasePrice", "averageCost"), 0.0),
            "splendid_product_id": external_id,
            "splendid_is_imported": True,
        }
        if "sale_ok" in self.env["product.template"]._fields:
            vals["sale_ok"] = self._safe_bool(self._find_value(payload, "isForSale"), True)
        if "purchase_ok" in self.env["product.template"]._fields:
            vals["purchase_ok"] = self._safe_bool(self._find_value(payload, "isForPurchase"), True)
        if "company_id" in self.env["product.template"]._fields:
            vals["company_id"] = self.company_id.id
        vals.update(self._product_type_vals(payload))
        barcode = self._safe_barcode(self._find_value(payload, "barcode"), product=product)
        if barcode and "barcode" in self.env["product.template"]._fields:
            vals["barcode"] = barcode
        description = self._find_value(payload, "description", "shortDescription", "catalogContent")
        if description:
            vals["description_sale"] = description
            vals["description_purchase"] = description
        income_account = self._resolve_account(self._find_value(payload, "salesAccountId"))
        expense_account = self._resolve_account(self._find_value(payload, "expenseAccountId"))
        if income_account and "property_account_income_id" in self.env["product.template"]._fields:
            vals["property_account_income_id"] = income_account.id
        if expense_account and "property_account_expense_id" in self.env["product.template"]._fields:
            vals["property_account_expense_id"] = expense_account.id
        if not product:
            domain = [("default_code", "=", sku)]
            if "company_id" in self.env["product.template"]._fields:
                domain = ["&"] + domain + ["|", ("company_id", "=", False), ("company_id", "=", self.company_id.id)]
            product = self.env["product.template"].with_company(self.company_id).sudo().search(domain, limit=1)
        if product:
            product.write(vals)
        else:
            product = self.env["product.template"].with_company(self.company_id).sudo().create(vals)
        self._set_mapping("product", external_id, product, payload, name)
        return product

    def _selection_has_value(self, model, field_name, value):
        field = model._fields.get(field_name)
        if not field or not getattr(field, "selection", False):
            return False
        selection = field.selection
        if isinstance(selection, str):
            selection = getattr(model, selection)()
        elif callable(selection):
            selection = selection(model)
        return value in [item[0] for item in (selection or [])]

    def _product_type_vals(self, payload):
        product_model = self.env["product.template"]
        vals = {}
        text = " ".join(str(x or "") for x in (
            self._find_value(payload, "type"),
            self._find_value(payload, "productType"),
            self._find_value(payload, "itemType"),
            self._find_value(payload, "category"),
            self._find_value(payload, "productCategoryName"),
        )).lower()
        is_service = "service" in text
        is_combo = any(word in text for word in ("combo", "bundle", "kit", "assembly")) or self._safe_bool(self._find_value(payload, "hasProductBreakup"), False)
        track_inventory = self._safe_bool(self._find_value(payload, "trackInventory"), False)
        odoo_type = "service" if is_service else ("combo" if is_combo else "consu")
        if "type" in product_model._fields:
            if self._selection_has_value(product_model, "type", odoo_type):
                vals["type"] = odoo_type
            elif self._selection_has_value(product_model, "type", "consu"):
                vals["type"] = "consu"
        if "detailed_type" in product_model._fields:
            if self._selection_has_value(product_model, "detailed_type", odoo_type):
                vals["detailed_type"] = odoo_type
            elif self._selection_has_value(product_model, "detailed_type", "consu"):
                vals["detailed_type"] = "consu"
        if "is_storable" in product_model._fields:
            vals["is_storable"] = bool(track_inventory and not is_service)
        return vals

    def _safe_barcode(self, value, product=False):
        barcode = str(value or "").strip()
        if not barcode:
            return False
        barcode = barcode[:64]
        Product = self.env["product.template"].with_company(self.company_id).sudo()
        domain = [("barcode", "=", barcode)]
        if product:
            domain.append(("id", "!=", product.id))
        if Product.search(domain, limit=1):
            return False
        return barcode

    def _import_warehouses(self, payload):
        external_id = self._external_id(payload)
        warehouse = self._mapped_record("warehouse", external_id, "stock.warehouse")
        name = self._find_value(payload, "name", "displayName", "code") or _("Splendid Warehouse %s") % external_id
        code_source = str(self._find_value(payload, "code", "number") or name or external_id).upper()
        code = "".join(ch for ch in code_source if ch.isalnum())[:5] or ("SP%s" % external_id)[-5:]
        Warehouse = self.env["stock.warehouse"].with_company(self.company_id).sudo()
        if not warehouse:
            warehouse = Warehouse.search([("company_id", "=", self.company_id.id), "|", ("name", "=", name), ("code", "=", code)], limit=1)
        if not warehouse:
            original_code = code
            seq = 1
            while Warehouse.search([("company_id", "=", self.company_id.id), ("code", "=", code)], limit=1):
                code = (original_code[:3] + str(seq))[:5]
                seq += 1
            warehouse = Warehouse.create({"name": name, "code": code, "company_id": self.company_id.id})
        else:
            warehouse.write({"name": name})
        if "splendid_warehouse_id" in warehouse._fields:
            warehouse.write({"splendid_warehouse_id": external_id, "splendid_is_imported": True})
        self._set_mapping("warehouse", external_id, warehouse, payload, name)
        return warehouse

    def _import_bank_accounts(self, payload):
        external_id = self._external_id(payload)
        Journal = self.env["account.journal"].with_company(self.company_id).sudo()
        journal = Journal.search([("company_id", "=", self.company_id.id), ("splendid_bank_account_id", "=", external_id)], limit=1)
        bank_name = self._find_value(payload, "bankName") or "Bank"
        account_title = self._find_value(payload, "accountTitle") or bank_name
        account_number = self._find_value(payload, "accountNumber")
        display_name = "%s - %s" % (bank_name, account_title)
        default_account = self._resolve_account(self._find_value(payload, "accountId"), self._find_value(payload, "code"))
        if not journal and account_number:
            journal = Journal.search([("company_id", "=", self.company_id.id), ("bank_acc_number", "=", account_number)], limit=1)
        vals = {
            "name": display_name[:100],
            "type": "bank",
            "code": self._unique_journal_code(self._find_value(payload, "code") or bank_name, journal=journal),
            "company_id": self.company_id.id,
            "splendid_bank_account_id": external_id,
            "splendid_bank_account_account_id": str(self._find_value(payload, "accountId") or ""),
            "splendid_is_imported": True,
        }
        if default_account and "default_account_id" in Journal._fields:
            vals["default_account_id"] = default_account.id
        bank_account = self._get_or_create_partner_bank(payload)
        if bank_account and "bank_account_id" in Journal._fields:
            vals["bank_account_id"] = bank_account.id
        if journal:
            journal.write(vals)
        else:
            journal = Journal.create(vals)
        self._set_mapping("bank_account", external_id, journal, payload, display_name)
        return journal

    def _unique_journal_code(self, source, journal=False):
        base = "".join(ch for ch in str(source or "BNK").upper() if ch.isalnum())[:5] or "BNK"
        Journal = self.env["account.journal"].with_company(self.company_id).sudo()
        code = base
        seq = 1
        while Journal.search([("company_id", "=", self.company_id.id), ("code", "=", code), ("id", "!=", journal.id if journal else 0)], limit=1):
            suffix = str(seq)
            code = (base[: max(1, 5 - len(suffix))] + suffix)[:5]
            seq += 1
        return code

    def _get_or_create_partner_bank(self, payload):
        account_number = self._find_value(payload, "accountNumber")
        if not account_number:
            return self.env["res.partner.bank"]
        Bank = self.env["res.bank"].sudo()
        PartnerBank = self.env["res.partner.bank"].sudo()
        bank_name = self._find_value(payload, "bankName")
        bank = Bank.search([("name", "=", bank_name)], limit=1) if bank_name else Bank
        if not bank and bank_name:
            bank = Bank.create({"name": bank_name})
        bank_account = PartnerBank.search([("acc_number", "=", account_number)], limit=1)
        vals = {"acc_number": account_number, "partner_id": self._company_partner().id}
        if bank:
            vals["bank_id"] = bank.id
        if "company_id" in PartnerBank._fields:
            vals["company_id"] = self.company_id.id
        if bank_account:
            bank_account.write(vals)
        else:
            bank_account = PartnerBank.create(vals)
        return bank_account

    def _get_tax_country_id(self):
            self.ensure_one()
            country = self.company_id.account_fiscal_country_id or self.company_id.country_id
            if not country:
                raise UserError(_("Please set Country / Fiscal Country on company %s before syncing taxes.") % self.company_id.display_name)
            return country.id


    def _import_taxes(self, payload):
        self.ensure_one()

        external_id = self._external_id(payload)
        name = self._find_value(payload, "name", "abbreviation") or _("Splendid Tax %s") % external_id
        abbreviation = self._find_value(payload, "abbreviation")
        rate = self._safe_float(self._find_value(payload, "rate"), 0.0)
        active = self._safe_bool(self._find_value(payload, "isActive"), True)
        tax_country_id = self._get_tax_country_id()

        created_taxes = self.env["account.tax"].with_company(self.company_id).sudo()

        tax_defs = []

        if self._safe_bool(self._find_value(payload, "out"), False):
            tax_defs.append({
                "tax_use": "sale",
                "name": "%s (Sale)" % name,
                "account_id": self._find_value(payload, "accountOutId"),
            })

        if self._safe_bool(self._find_value(payload, "in"), False):
            tax_defs.append({
                "tax_use": "purchase",
                "name": "%s (Purchase)" % name,
                "account_id": self._find_value(payload, "accountInId"),
            })

        if not tax_defs:
            tax_defs.append({
                "tax_use": "none",
                "name": name,
                "account_id": False,
            })

        Tax = self.env["account.tax"].with_company(self.company_id).sudo()

        for tax_def in tax_defs:
            tax_use = tax_def["tax_use"]

            domain = [
                ("company_id", "=", self.company_id.id),
                ("splendid_tax_id", "=", str(external_id)),
                ("splendid_tax_use", "=", tax_use),
            ]

            tax = Tax.search(domain, limit=1)

            vals = {
                "name": tax_def["name"],
                "amount": rate,
                "amount_type": "percent",
                "type_tax_use": tax_use,
                "active": active,
                "company_id": self.company_id.id,
                "country_id": tax_country_id,
                "splendid_tax_id": str(external_id),
                "splendid_tax_use": tax_use,
                "splendid_is_imported": True,
            }

            if tax:
                tax.write(vals)
            else:
                tax = Tax.create(vals)

            self._set_mapping(
                "tax",
                "%s_%s" % (external_id, tax_use),
                tax,
                payload,
                tax_def["name"],
            )

            created_taxes |= tax

        return created_taxes[:1]
    def _upsert_tax(self, payload, direction):
        external_id = self._external_id(payload)
        Tax = self.env["account.tax"].with_company(self.company_id).sudo()
        tax = Tax.search([
            ("company_id", "=", self.company_id.id),
            ("splendid_tax_id", "=", external_id),
            ("splendid_tax_direction", "=", direction),
        ], limit=1)
        base_name = self._find_value(payload, "name", "abbreviation") or _("Splendid Tax %s") % external_id
        suffix = "Sale" if direction == "sale" else "Purchase"
        account_id = self._find_value(payload, "accountOutId" if direction == "sale" else "accountInId")
        account = self._resolve_account(account_id)
        vals = {
            "name": "%s (%s)" % (base_name, suffix),
            "amount": self._safe_float(self._find_value(payload, "rate"), 0.0),
            "amount_type": "percent",
            "type_tax_use": direction,
            "company_id": self.company_id.id,
            "active": self._safe_bool(self._find_value(payload, "isActive"), True),
            "splendid_tax_id": external_id,
            "splendid_tax_direction": direction,
            "splendid_is_imported": True,
        }
        if tax:
            tax.write(vals)
        else:
            tax = Tax.create(vals)
        if account:
            self._set_tax_account(tax, account)
        self._set_mapping("tax_%s" % direction, external_id, tax, payload, vals["name"])
        return tax

    def _set_tax_account(self, tax, account):
        for field_name in ("invoice_repartition_line_ids", "refund_repartition_line_ids"):
            lines = getattr(tax, field_name, False)
            if not lines:
                continue
            for line in lines.filtered(lambda l: getattr(l, "repartition_type", False) == "tax"):
                try:
                    line.account_id = account.id
                except Exception:  # pylint: disable=broad-except
                    _logger.debug("Could not set tax repartition account for %s", tax.display_name)
        return True
